''' Wilton Oliver | CSCI 1551 - Concepts 3D Games Engines | 2026-02-12 '''


# Import general app dependencies
from direct.showbase.ShowBase import ShowBase


# Create 'main' class for in-app code execution
class mySpaceJam(ShowBase):
    # Define what will execute as soon as the app is run
    def __init__(self):
        ShowBase.__init__(self)
        self.createScene()
 
    # Create the scene - skybox, planets, playermodel, etc.    
    def createScene(self):
        # Load, Render the 'universe' skybox
        self.Universe = self.loader.loadModel("Assets/Universe/Universe/Universe.x")
        self.UniverseTexture = self.loader.loadTexture("Assets/Universe/universe-texture.jpg")
        self.Universe.setTexture(self.UniverseTexture)
        self.Universe.reparentTo(self.render)
        self.Universe.setScale(15000)

        # Load, Render Planet 1 - "Solterra"
        self.Planet1 = self.loader.loadModel("Assets/Planets/protoPlanet.x")
        self.Planet1Texture = self.loader.loadTexture("Assets/Planets/molten-planet [solterra].jpg")
        self.Planet1.setTexture(self.Planet1Texture)
        self.Planet1.reparentTo(self.render)
        self.Planet1.setPos(200, 5000, 89)
        self.Planet1.setScale(250)

        # Load, Render Planet 2 - "Dusk"
        self.Planet2 = self.loader.loadModel("Assets/Planets/protoPlanet.x")
        self.Planet2Texture = self.loader.loadTexture("Assets/Planets/dust-planet [dusk].jpg")
        self.Planet2.setTexture(self.Planet2Texture)
        self.Planet2.reparentTo(self.render)
        self.Planet2.setPos(5300, 5750, 550)
        self.Planet2.setScale(500)

        # Load, Render Planet 3 - "Atla"
        self.Planet3 = self.loader.loadModel("Assets/Planets/protoPlanet.x")
        self.Planet3Texture = self.loader.loadTexture("Assets/Planets/water-planet [atla].jpg")
        self.Planet3.setTexture(self.Planet3Texture)
        self.Planet3.reparentTo(self.render)
        self.Planet3.setPos(-5030, 6500, -2900)
        self.Planet3.setScale(1250)

        # Load, Render Planet 4 - "Gamma"
        self.Planet4 = self.loader.loadModel("Assets/Planets/protoPlanet.x")
        self.Planet4Texture = self.loader.loadTexture("Assets/Planets/gem-planet [gamma].jpg")
        self.Planet4.setTexture(self.Planet4Texture)
        self.Planet4.reparentTo(self.render)
        self.Planet4.setPos(-1700, 8000, 3275)
        self.Planet4.setScale(1500)

        # Load, Render Planet 5 - "Hearth"
        self.Planet5 = self.loader.loadModel("Assets/Planets/protoPlanet.x")
        self.Planet5Texture = self.loader.loadTexture("Assets/Planets/dry-planet [hearth].jpg")
        self.Planet5.setTexture(self.Planet5Texture)
        self.Planet5.reparentTo(self.render)
        self.Planet5.setPos(3500, 1500, -2051)
        self.Planet5.setScale(890)

        # Load, Render Planet 6 - "Aero"
        self.Planet6 = self.loader.loadModel("Assets/Planets/protoPlanet.x")
        self.Planet6Texture = self.loader.loadTexture("Assets/Planets/cloud-planet [aero].jpg")
        self.Planet6.setTexture(self.Planet6Texture)
        self.Planet6.reparentTo(self.render)
        self.Planet6.setPos(520, 0, 8000)
        self.Planet6.setScale(2200)

        # Load, Render Space Station - "Base"(?)
        self.SpaceStation = self.loader.loadModel("Assets/Space Station/SpaceStation1B/spaceStation.x")
        self.SpaceStation.reparentTo(self.render)
        self.SpaceStation.setPos(0, 2500, 3000)
        self.SpaceStation.setHpr(15, 95, 200)
        self.SpaceStation.setScale(50)

        # Load, Render Space Ship - "Player"
        self.SpaceStation = self.loader.loadModel("Assets/Spaceships/Phaser/phaser.x") # I can't tell if this or 'drone defender' is the player...
        self.SpaceStation.reparentTo(self.render)
        self.SpaceStation.setPos(0, 50, 0)
        self.SpaceStation.setHpr(0, 45, 0)
        self.SpaceStation.setScale(5)


# Define 'main' class as app and run it when file is executed
app = mySpaceJam()
app.run()

